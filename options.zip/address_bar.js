/**
 * define AddressBar : Third Party UI Options Page
 *
 ***/
cr.define('options', function() {
  var OptionsPage = options.OptionsPage;

  function AddressBar() {
      OptionsPage.call(this, 'addressbar', '\u9009\u9879 - \u5730\u5740\u680F', 'addressBarPage');
    }

  cr.addSingletonGetter(AddressBar);

  AddressBar.prototype = {
    __proto__: options.OptionsPage.prototype,

    initializePage: function(){
      OptionsPage.prototype.initializePage.call(this);
	  //
      $('certificatesManageButton').onclick = function(event) {
        chrome.send('showManageSSLCertificates');
      };
      /*$('sslCheckRevocation').onclick = function(event) {
        chrome.send('checkRevocationCheckboxAction',
            [String($('sslCheckRevocation').checked)]);
        onOptionSavedSuccessfully();
      };
	  // Set the checked state for the sslCheckRevocation checkbox.
	  AdvancedOptions.SetCheckRevocationCheckboxState = function(
		  checked, disabled) {
		$('sslCheckRevocation').checked = checked;
		$('sslCheckRevocation').disabled = disabled;
	  }*/
    }
  };

  return {
      AddressBar: AddressBar
    };
});
