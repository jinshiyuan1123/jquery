﻿/**
 * define Speedup Options : Third Party UI Options Page
 *
 ***/
cr.define('options', function() {
  var OptionsPage = options.OptionsPage;

  function SafeSettings() {
    OptionsPage.call(this, 'safe', '选项 - 安全设置', 'safePage');
  }

  cr.addSingletonGetter(SafeSettings);

  SafeSettings.prototype = {
    __proto__: options.OptionsPage.prototype,
    _360safeInstalled: false,
    _nativeStateData: {},

    initializePage: function() {
      var self = this;
      OptionsPage.prototype.initializePage.call(this);

      self.bindEvents();

      window.onGetSafeOptions = function(data) {
        data = data && data[0];
        self._nativeStateData = data;
        self._360safeInstalled = data['360safe_installed'] == true;
        var urlsafeChecked = data['urlsafe'] == true
        for (var x in data) {
          var $checkbox = $$('#safePage :checkbox[_pref="se.safe.' + x + '"]');
          if ($checkbox.length > 0)　 {
            switch (x) {
              case 'shoppingsafe':
              case 'shoppingindemnity':
                if (urlsafeChecked) {
                  $checkbox[0].checked = data[x];
                }
                break;
              default:
                $checkbox[0].checked = data[x];
                break;
            }
            if (x == 'urlsafe') {
              $checkbox.parent().nextAll('.warn')[0].hidden = $checkbox[0].checked;
            }
            if (x == 'sandboxprotection') {
              $checkbox.parent().nextAll('.warn')[0].hidden = $checkbox[0].checked;
            }
          }
        }
        self.calcTotal();
      };
      chrome.send('getSafeOptions', ['onGetSafeOptions']);

      var osVer;
      try {
        osVer = navigator.userAgent.match(/windows nt ([\d\.]+)/i)[1];
      } catch (e) {}
      if (!osVer || osVer < '6.1') {
        $$('[_pref="se.safe.injectionprevention"]').parents('.checkbox').hide();
      }
    },

    /**
     * onShowPage
     */
    didShowPage: function() {

    },

    bindEvents: function() {
      var self = this;

      $$('#notinstall-360safe-popup .btn-close').on('click', function() {
        self.hideInstall360safe();
      });

      $$('#notinstall-360safe-popup .green-btn').on('click', function() {
        if ($$(this).text().indexOf('安装') > -1) {
          // chrome.send('install_360safe');
          window.open('http://weishi.360.cn/');
        }
        self.hideInstall360safe();
      });

      $$(window).on('focus', function() {
        if (onFocusReload) {
          onFocusReload = false;
        }
        chrome.send('getSafeOptions', ['onGetSafeOptions']);
      });

      var onFocusReload = false;

      var $safeCheckboxs = $$('#safeSection :checkbox');
      $safeCheckboxs.on('change', function() {
        var text = $$(this).next('span').text();
        var pref = $$(this).attr('_pref');
        var needChromeSend = true;
        var urlsafeChecked;
        switch (pref) {
          case 'se.safe.360safe':
            if (this.checked && !self._360safeInstalled) {
              self.showInstall360safe(text);
              this.checked = false;
            } else {
              this.checked = !this.checked;
              self.showCannotClose();
            }
            break;
          case 'se.safe.downloadsafe':
            onFocusReload = true;
            this.checked = !this.checked;
            if (!self._360safeInstalled) {
              self.showInstall360safe(text);
            }
            break;
          case 'se.safe.shoppingsafe':
          case 'se.safe.shoppingindemnity':
            var oldChecked = !this.checked;
            var realChecked = self._nativeStateData[pref.split('.')[2]];
            if (!oldChecked) {
              if (!$$('#safePage :checkbox[_pref="se.safe.urlsafe"]')[0].checked) {
                chrome.send('setSafeOptions', ['se.safe.urlsafe', true]);
                urlsafeChecked = true;
              }
            }
            if (oldChecked != realChecked) {
              needChromeSend = false;
              chrome.send('setSafeOptions', ['se.safe.urlsafe', true]);
              urlsafeChecked = true;
            } else {
              onFocusReload = true;
              this.checked = !this.checked;
              if (!self._360safeInstalled) {
                self.showInstall360safe(text);
              }
            }
            break;
          case 'se.safe.urlsafe':
            urlsafeChecked = this.checked;
            $$(this).parent().nextAll('.warn')[0].hidden = this.checked;
            break;
          case 'se.safe.sandboxprotection':
            $$(this).parent().nextAll('.warn')[0].hidden = this.checked;
            break;
        }
        if (needChromeSend) {
          chrome.send('setSafeOptions', [pref, this.checked]);
        }
        if (urlsafeChecked !== undefined) {
          if (urlsafeChecked) {
            chrome.send('getSafeOptions', ['onGetSafeOptions']);
          } else {
            $$('#safePage :checkbox[_pref="se.safe.shoppingsafe"],#safePage :checkbox[_pref="se.safe.shoppingindemnity"]').attr('checked', false);
          }
        }
        self.calcTotal();
      });
    },

    calcTotal: function() {
      var self = this;

      var $safeCheckboxs = $$('#safeSection :checkbox');
      var total = 0;
      $safeCheckboxs.filter(':checked').each(function(i, item) {
        total += parseInt(item.value);
      });

      self.setCircleProgress(total);
    },

    showInstall360safe: function(text) {
      $$('body').addClass('show-dlg');
      $$('.mask').show();
      $$('#notinstall-360safe-popup header h2').removeClass('cc');
      $$('#notinstall-360safe-popup header h2').text('未安装360安全卫士');
      $$('#notinstall-360safe-popup .pop-up-cont p').html('<span></span>需要360安全卫士支持，请先安装安全卫士');
      $$('#notinstall-360safe-popup .pop-up-cont p span').text(text);
      $$('#notinstall-360safe-popup .pop-up-cont button.green-btn').text('快速安装');
      $$('#notinstall-360safe-popup').show();
    },
    showCannotClose: function() {
      $$('body').addClass('show-dlg');
      $$('.mask').show();
      $$('#notinstall-360safe-popup header h2').addClass('cc');
      $$('#notinstall-360safe-popup header h2').text('功能关闭失效');
      $$('#notinstall-360safe-popup .pop-up-cont p').text('为保证系统安全，多层系统防护不可关闭');
      $$('#notinstall-360safe-popup .pop-up-cont button.green-btn').text('确定');
      $$('#notinstall-360safe-popup').show();
    },
    hideInstall360safe: function() {
      $$('#notinstall-360safe-popup').hide();
      $$('body').removeClass('show-dlg');
      $$('.mask').hide();
    },

    setCircleProgress: function(percent) {
      // e70748   ff1689
      // f85b2a   fdab11
      // 08e773   3ad5e0
      $$('#safePage .circle-progress .progress').text(percent);
      var $circleBorder = $$('#safePage .circle-progress .circle-border');
      $circleBorder.css('transform', 'rotate(' + percent * 360 / 100 + 'deg)');
      var $colors = $$('#radial-gradient stop');
      if (percent < 50) {
        $colors.eq(1).attr('stop-color', '#e70748');
        $colors.eq(0).attr('stop-color', '#ff1689');
        $circleBorder.attr('color', 'red');
      } else if (percent <= 99) {
        $colors.eq(1).attr('stop-color', '#f85b2a');
        $colors.eq(0).attr('stop-color', '#fdab11');
        $circleBorder.attr('color', 'yellow');
      } else {
        $colors.eq(1).attr('stop-color', '#08e773');
        $colors.eq(0).attr('stop-color', '#3ad5e0');
        $circleBorder.attr('color', 'green');
      }

      var circleSlice = 2 * Math.PI / 100;
      var currentAngle = percent * circleSlice;
      var point = this.getPointOfCircle(currentAngle);
      $$('#radial-gradient').attr(point);

      var $circle = $$('.radial-progress-bar circle').eq(1);
      var circumference = parseFloat($circle.css('stroke-dasharray'));
      $circle.css('stroke-dashoffset', ((100 - percent) / 100) * circumference);
    },

    getPointOfCircle: function(angle) {
      var radius = 0.5

      var x = radius + (radius * Math.cos(angle))
      var y = radius + (radius * Math.sin(angle))

      return {
        fx: x,
        fy: y
      };

    }
  };

  return {
    SafeSettings: SafeSettings
  };
});