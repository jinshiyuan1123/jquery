/**
 * define adblockExceptionOptions 
 * 
 ***/
cr.define('options', function () {
    var OptionsPage = options.OptionsPage;

    function ADBlockExceptionOptions() {
        OptionsPage.call(this, 'adblockException', '', 'adblockExceptionPage');
    }

    cr.addSingletonGetter(ADBlockExceptionOptions);

    ADBlockExceptionOptions.prototype = {
        __proto__: options.OptionsPage.prototype,

        initializePage: function () {
            OptionsPage.prototype.initializePage.call(this);
            var adExceptionList = $("adblockExceptionList");
            options.contentSettings.ExceptionsList.decorate(adExceptionList);
        } //initializePage
    };
    return {
        ADBlockExceptionOptions: ADBlockExceptionOptions
    };
});
