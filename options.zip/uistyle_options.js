﻿/**
 * define Speedup Options : Third Party UI Options Page
 *
 ***/
cr.define('options', function() {
  var OptionsPage = options.OptionsPage;

  function UistyleOptions() {
    OptionsPage.call(this, 'uistyle', '选项 - 界面设置', 'uistylePage');
  }

  cr.addSingletonGetter(UistyleOptions);

  UistyleOptions.prototype = {
    __proto__: options.OptionsPage.prototype,

    initializePage: function() {
      OptionsPage.prototype.initializePage.call(this);

      Preferences.getInstance().addEventListener('browser.use_custom_font_size', function(e) {
        $$('[pref="browser.default_font_size"]').attr('disabled', (e.value || {}).value != 1);
        $$('#fontsize_option_tips').css('display', (e.value || {}).value != 1 ? 'none':'');
      });

      Preferences.getInstance().addEventListener('browser.default_font_size', function(e) {
        $$('#custom_fontsize_preview').css('font-size', (e.value || {}).value + 'pt');
      });

      Preferences.getInstance().addEventListener('skin.info', function(e) {
        var skinId = e.value && e.value.value && e.value.value.id;
        var $option = $$('[pref="se.browser.layout.show_menu_bar"]').parents('.checkbox');
        if (skinId != 8 && skinId != 9 && skinId != 1110 && skinId != 1257 && skinId != 1153 && skinId != 1170 && skinId != 1168 && skinId != 1169) {
          $option.removeAttr('hidden');
        } else {
          $option.attr('hidden', 'hidden');
        }
      });
    },
  };

  return {
    UistyleOptions: UistyleOptions
  };
});